// Roll No: L1F26BSCS0117
// Name: M.Saad Lashari

#include <iostream>
using namespace std;

int main() {
    int number;

    cout << "Enter an integer: ";
    cin >> number;

    if (number > 0) {
        cout << "Positive number" << endl;
    }

    return 0;
}

/*
Observation:
For 0 and -4, nothing is printed because the condition (number > 0) is false.
Since we did not use an else block, the program simply exits without showing any message.
*/

