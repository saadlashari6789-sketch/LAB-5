// Roll No: L1F26BSCS0117
// Name: M.Saad Lashari

#include <iostream>
using namespace std;

int main() {
    int firstNumber, secondNumber;

    cout << "Enter two numbers: ";
    cin >> firstNumber >> secondNumber;

    // comparing first number with second number
    if (firstNumber > secondNumber) {
        cout << "First number is greater" << endl;
    }
    else {
        cout << "First number is not greater" << endl;
    }

    return 0;
}

/*
Observation:
When both numbers are equal, it prints "First number is not greater".
This happens because the condition (5 > 5) is false, so the program goes to the else block.
*/
