// Roll No: L1F26BSCS0117
// Name: M.Saad Lashari

#include <iostream>
using namespace std;

int main() {
    int age;

    cout << "Enter your age: ";
    cin >> age;

    // checking to the voting eligibility
    if (age >= 18) {
        cout << "Eligible to vote." << endl;
    }
    else {
        cout << "Not eligible to vote." << endl;
    }

    return 0;
}
