// Roll No: L1F26BSCS0117
// Name: M.Saad Lashari

#include <iostream>
using namespace std;

int main() {
    int units;

    cout << "Enter monthly units: ";
    cin >> units;

    // checking electricity usage category
    if (units <= 100) {
        cout << "Usage category: Low usage" << endl;
    }
    else if (units <= 300) {
        cout << "Usage category: Medium usage" << endl;
    }
    else {
        cout << "Usage category: High usage" << endl;
    }

    return 0;
}
