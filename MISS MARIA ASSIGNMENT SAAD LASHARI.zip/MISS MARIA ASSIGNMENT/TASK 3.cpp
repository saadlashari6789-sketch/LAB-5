// Roll No: L1F26BSCS0117
// Name: M.Saad Lashari

#include <iostream>
using namespace std;

int main() {
    int number;

    cout << "Enter an integer: ";
    cin >> number;

    // checking even or odd
    if (number % 2 == 0) {
        cout << "Even number" << endl;
    }
    else {
        cout << "Odd number" << endl;
    }

    return 0;
}

/*
Observation:
Zero is even because 0 divided by 2 leaves a remainder of 0, so the condition becomes true.
*/
