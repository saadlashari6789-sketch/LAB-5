// Roll No: L1F26BSCS0117
// Name: M.Saad Lashari

#include <iostream>
using namespace std;

int main() {
    int billAmount;

    cout << "Enter bill amount: ";
    cin >> billAmount;

    cout << "Bill amount: Rs. " << billAmount << endl;

    if (billAmount >= 5000) {
        cout << "You qualify for a discount." << endl;
    }

    return 0;
}

/*
Observation:
The >= operator is better than > because the discount starts exactly at 5000.
If we use >, then a bill of exactly 5000 will not get the discount, which is wrong.
*/
