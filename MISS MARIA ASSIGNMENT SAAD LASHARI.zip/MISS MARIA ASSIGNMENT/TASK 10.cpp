// Roll No: L1F26BSCS0117
// Name: M.Saad Lashari

#include <iostream>
using namespace std;

int main() {
    int marks;

    cout << "Enter marks: ";
    cin >> marks;

    // checking scholarship eligibility based on flowchart
    if (marks >= 85) {
        cout << "Scholarship awarded" << endl;
    }
    else {
        cout << "Scholarship not awarded" << endl;
    }

    return 0;
}
